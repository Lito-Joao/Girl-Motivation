# Girl Motivation Website

Este é o site oficial da **Girl Motivation**.

## Publicação no GitHub Pages
1. Faça login no GitHub.
2. Crie um novo repositório público (ex: `girl-motivation`).
3. Carregue todos os arquivos deste projeto (`index.html`, `style.css`, `script.js`, `logo.png`).
4. Vá em **Settings > Pages** e selecione a branch `main` e a pasta `/ (root)`.
5. O site ficará acessível em:  
   `https://SEU-USUARIO.github.io/girl-motivation`
